package cards;

import game.GameSession;
import players.Player;

/**
 * Represents a number card in the UNO game.
 */
public class NumberCard extends Card {

    /**
     * Constructs a new NumberCard.
     *
     * @param color the color of the card
     * @param value the value of the card
     */
    public NumberCard(String color, String value) {
        super(color, value, Integer.parseInt(value));
    }

    /**
     * Plays this card in the given game session.
     *
     * @param game the current game session
     */
    public void playCard(GameSession game) {
        int index = game.getCurrentPlayerIndex();
        Player thisPlayer = game.getPlayers().get(index);
        boolean matchByValue = this.getValue().equals(game.getDiscardPileTopCard().getValue());

        if (matchByValue) {
            game.setPileColor(this.getColor());
        }

        thisPlayer.playCard(this);
        game.getDiscardPile().add(this);
    }

    /**
     * Gets the image path of this card.
     *
     * @return the image path of the card
     */
    @Override
    public String getCardImage() {
        return "src/images/cards/" + StringUtils.capitalize(getColor()) + "_" + getValue() + ".jpg";
    }
}
