package cards;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * Represents a deck of cards in the UNO game.
 */
public class Deck {
	
    private List<Card> cards;

    /**
     * Constructs a new Deck and initializes it with a standard set of UNO cards.
     */
    public Deck() {
        this.cards = new ArrayList<>();
        shuffle();
        createDeck();
    }
    
    
    public Deck(List<Card> cards) {
    	setCards(cards);
    }
    /**
     * Gets the list of cards in the deck.
     * 
     * @return the list of cards in the deck
     */
    public List<Card> getCards() {
        return cards;
    }

    /**
     * Sets the list of cards in the deck.
     * 
     * @param cards the new list of cards
     */
    public void setCards(List<Card> cards) {
        this.cards = cards;
    }

    /**
     * Shuffles the deck using Collections.shuffle.
     */
    public void shuffle() {
        Collections.shuffle(cards);
    }

    /**
     * Initializes the deck with a standard set of UNO cards.
     */
    private void createDeck() {
        String[] colors = {"Red", "Yellow", "Blue", "Green"};

        // Add Wild cards
        for (int k = 0; k < 4; k++) {
            cards.add(new WildCard(WildCard.WildType.CHANGE_COLOR));
            cards.add(new WildCard(WildCard.WildType.DRAW_FOUR));
        }

        for (String color : colors) {
            // Add one zero card for each color
            cards.add(new NumberCard(color, "0"));

            // Add two of each Action card for each color
            cards.add(new ActionCard(color, ActionCard.ActionType.SKIP));
            cards.add(new ActionCard(color, ActionCard.ActionType.SKIP));
            cards.add(new ActionCard(color, ActionCard.ActionType.REVERSE));
            cards.add(new ActionCard(color, ActionCard.ActionType.REVERSE));
            cards.add(new ActionCard(color, ActionCard.ActionType.DRAW_TWO));
            cards.add(new ActionCard(color, ActionCard.ActionType.DRAW_TWO));

            // Add two of each number card (1 through 9) for each color
            for (int i = 1; i <= 9; i++) {
                cards.add(new NumberCard(color, Integer.toString(i)));
                cards.add(new NumberCard(color, Integer.toString(i)));
            }
        }
    }

    /**
     * Draws a card from the top of the deck.
     * 
     * @return the drawn card
     * @throws IllegalStateException if the deck is empty
     */
    public Card draw() throws IllegalStateException {
        if (cards.isEmpty()) {
            throw new IllegalStateException("No cards left to draw");
        }
        return cards.remove(0);  // Removes the top card from the deck and returns it
    }

    /**
     * Adds a card back to the deck at a random position and shuffles the deck.
     * 
     * @param card the card to be added back to the deck
     */
    public void shuffleBackInCard(Card card) {
        cards.add((int) (Math.random() * cards.size()), card);
        Collections.shuffle(cards);
    }
}
