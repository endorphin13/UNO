package cards;


import game.GameSession;

/**
 * Represents an action card in the UNO game.
 */
public class ActionCard extends Card {

    /**
     * Enum for the type of action the card performs.
     */
    public enum ActionType {
        SKIP, REVERSE, DRAW_TWO
    }

    private ActionType actionType;

    /**
     * Constructs an ActionCard with the specified color and action type.
     *
     * @param color      the color of the card
     * @param actionType the type of action the card performs
     */
    public ActionCard(String color, ActionType actionType) {
        super(color, "Action", 20);
        this.actionType = actionType;
    }

    /**
     * Gets the action type of the card.
     *
     * @return the action type of the card
     */
    public ActionType getActionType() {
        return actionType;
    }

    /**
     * Sets the action type of the card.
     *
     * @param actionType the new action type
     */
    public void setActionType(ActionType actionType) {
        this.actionType = actionType;
    }

    /**
     * Plays the action card, executing its effects on the game session.
     *
     * @param game the game session in which the card is played
     */
    @Override
    public void playCard(GameSession game) {
        switch (this.actionType) {
            case SKIP:
                game.setNextPlayerSkipTurn(true);
                break;
            case REVERSE:
                game.reverseGameDirection();
                break;
            case DRAW_TWO:
                game.getPlayers().get((game.getCurrentPlayerIndex() + 1) % game.getPlayers().size()).drawCards(2, game.getDeck());
                game.setNextPlayerSkipTurn(true);
                break;
        }
    }


    /**
     * Returns the image path of the card.
     *
     * @return the image path of the card
     */
    @Override
    public String getCardImage() {
        return "src/images/cards/" + StringUtils.capitalize(getColor()) + "_" + getActionType().toString().toLowerCase()
                + ".jpg";
    }
}
