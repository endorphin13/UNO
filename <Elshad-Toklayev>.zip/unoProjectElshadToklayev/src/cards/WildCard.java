package cards;


import game.GameSession;
import players.Player;

/**
 * Represents a Wild Card in the UNO game.
 */
public class WildCard extends Card {
	
    /**
     * Enum for the type of wild card.
     */
    public enum WildType {
        CHANGE_COLOR, DRAW_FOUR;
    }
    
    private WildType wildType;
    
    /**
     * Constructs a WildCard with the specified wild type.
     *
     * @param wildType the type of wild card
     */
    public WildCard(WildType wildType) {
        super("None", "Wild", 50);
        this.wildType = wildType;
    }
    
    /**
     * Gets the wild type of the card.
     *
     * @return the wild type of the card
     */
    public WildType getWildType() {
        return wildType;
    }

    /**
     * Sets the wild type of the card.
     *
     * @param wildType the new wild type
     */
    public void setWildType(WildType wildType) {
        this.wildType = wildType;
    }

    /**
     * Plays the wild card, executing its effects on the game session.
     *
     * @param game the game session in which the card is played
     */
    public void playCard(GameSession game) {
        Player nextPlayer = game.getPlayers().get((game.getCurrentPlayerIndex() + 1) % game.getPlayers().size());

        switch (this.getWildType()) {
            case CHANGE_COLOR:
                game.handleColorChange(game.getPlayers().get(game.getCurrentPlayerIndex()));
                break;
            case DRAW_FOUR:
                nextPlayer.drawCards(4, game.getDeck());
                game.setNextPlayerSkipTurn(true);
                game.handleColorChange(game.getPlayers().get(game.getCurrentPlayerIndex()));
                break;
        }
    }

    /**
     * Returns the image path of the card.
     *
     * @return the image path of the card
     */
    @Override
    public String getCardImage() {
        return "src/images/cards/" + StringUtils.capitalize(getWildType().toString()) + ".jpg";
    }
}
