package cards;

import game.GameSession;

/**
 * Represents an abstract card in the UNO game.
 */
public abstract class Card {
	
	private String color;
	private String value;
	private int score;
	
    /**
     * Constructs a new Card.
     * 
     * @param color the color of the card
     * @param value the value or type of the card
     * @param score the score value of the card
     */
	public Card(String color, String value, int score) {
		this.color = color;
		this.value = value;
		this.score = score;
	}
	
    /**
     * Gets the score value of the card.
     * 
     * @return the score value of the card
     */
	public int getScore() {
		return score;
	}

    /**
     * Sets the score value of the card.
     * 
     * @param score the new score value
     */
	public void setScore(int score) {
		this.score = score;
	}

    /**
     * Executes the effect of the card in the specified game session.
     * 
     * @param game the game session in which the card is played
     */
	public abstract void playCard(GameSession game);

    /**
     * Gets the color of the card.
     * 
     * @return the color of the card
     */
	public String getColor() {
		return color;
	}

    /**
     * Sets the color of the card.
     * 
     * @param color the new color of the card
     */
	public void setColor(String color) {
		this.color = color;
	}

    /**
     * Gets the value or type of the card.
     * 
     * @return the value or type of the card
     */
	public String getValue() {
		return value;
	}

    /**
     * Sets the value or type of the card.
     * 
     * @param value the new value or type of the card
     */
	public void setValue(String value) {
		this.value = value;
	}

    /**
     * Returns a string representation of the card.
     * 
     * @return a string representation of the card
     */
	@Override
    public String toString() {
        if ("Wild".equals(value)) {
            if ("Draw Four".equals(color)) {
                return "Wild Draw Four";
            }
            return "Wild Color Change";
        }
        return color + " " + value;
    }

    /**
     * Gets the image path of the card.
     * 
     * @return the image path of the card
     */
	public abstract String getCardImage();
}
