package gui;

import javax.swing.*;
import gui.utils.GradientPanel;
import gui.utils.PlaceHolderPasswordField;
import gui.utils.PlaceHolderTextField;
import java.awt.*;
import java.awt.event.*;
import java.io.*;

/**
 * The RegistrationPage class represents the registration window for the UNO game application.
 * It allows users to create a new account by providing a nickname and a password.
 */
@SuppressWarnings("serial")
public class RegistrationPage extends JFrame {
    private PlaceHolderTextField nicknameField;
    private PlaceHolderPasswordField passwordField;
    private PlaceHolderPasswordField confirmPasswordField;
    private JButton registerButton;
    private JLabel messageLabel;

    /**
     * Constructs a new RegistrationPage.
     * Sets the title, size, default close operation, and layout of the window.
     * Initializes the components of the registration page.
     */
    public RegistrationPage() {
        setTitle("Registration - UNO Game");
        setSize(800, 500);
        setContentPane(new GradientPanel());
        getContentPane().setLayout(null);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        initializeComponents();
        setVisible(true);
    }

    /**
     * Initializes the components of the registration page, including text fields, labels, and buttons.
     */
    private void initializeComponents() {
        JLabel nicknameLabel = new JLabel("Nickname:");
        nicknameLabel.setBounds(230, 150, 100, 30);
        getContentPane().add(nicknameLabel);

        nicknameField = new PlaceHolderTextField("Nickname");
        nicknameField.setBounds(360, 150, 180, 30);
        getContentPane().add(nicknameField);

        JLabel passwordLabel = new JLabel("Password:");
        passwordLabel.setBounds(230, 200, 100, 30);
        getContentPane().add(passwordLabel);

        passwordField = new PlaceHolderPasswordField("Password");
        passwordField.setBounds(360, 200, 180, 30);
        getContentPane().add(passwordField);

        JLabel confirmPasswordLabel = new JLabel("Confirm Password:");
        confirmPasswordLabel.setBounds(230, 250, 140, 30);
        getContentPane().add(confirmPasswordLabel);

        confirmPasswordField = new PlaceHolderPasswordField("Confirm Password");
        confirmPasswordField.setBounds(360, 250, 180, 30);
        getContentPane().add(confirmPasswordField);

        registerButton = new JButton("Register");
        registerButton.setBounds(400, 292, 100, 30);
        registerButton.addActionListener(this::registerAction);
        getContentPane().add(registerButton);

        messageLabel = new JLabel("", JLabel.CENTER);
        messageLabel.setBounds(250, 350, 290, 30);
        getContentPane().add(messageLabel);
    }

    /**
     * Handles the registration action when the register button is pressed.
     * Validates the input fields and saves the user data to a CSV file if valid.
     *
     * @param event the ActionEvent triggered by pressing the register button
     */
    private void registerAction(ActionEvent event) {
        String nickname = nicknameField.getText();
        String password = new String(passwordField.getPassword());
        String confirmPassword = new String(confirmPasswordField.getPassword());

        if (!password.equals(confirmPassword)) {
            showMessage("Passwords do not match!", Color.RED);
        } else if (nickname.isEmpty() || password.isEmpty()) {
            showMessage("Please fill in all fields.", Color.RED);
        } else {
            if (saveUserData(nickname, password)) {
                showMessage("Registration successful!", new Color(0, 128, 0));
                dispose();
                new LoginPage();
            } else {
                showMessage("Error saving user data.", Color.RED);
            }
        }
    }
    
    /**
     * Sets the message text and color on the message label.
     *
     * @param message The message to be displayed.
     * @param color The color of the message text.
     */
    private void showMessage(String message, Color color) {
        messageLabel.setText(message);
        messageLabel.setForeground(color);
    }

    /**
     * Saves user data to the data.csv file.
     *
     * @param nickname The user's nickname.
     * @param password The user's password.
     * @return true if the data was saved successfully, false if there was an error.
     */
    private boolean saveUserData(String nickname, String password) {
        try (PrintWriter pw = new PrintWriter(new BufferedWriter(new FileWriter("src/files/data.csv", true)))) {
            pw.println(nickname + "," + password);
            return true;
        } catch (IOException e) {
            e.printStackTrace();
            return false;
        }
    }
    
    /**
     * The main method to launch the registration page.
     *
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        SwingUtilities.invokeLater(RegistrationPage::new);
    }
}
