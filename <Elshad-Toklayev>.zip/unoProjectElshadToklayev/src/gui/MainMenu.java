package gui;

import javax.swing.*;
import javax.swing.border.EmptyBorder;

import game.GameSession;
import game.SaveLoadManager;

import java.awt.*;
import java.io.IOException;

/**
 * The MainMenu class represents the main menu window for the UNO game application.
 * It provides a user interface for selecting the number of bots, entering a session name, and starting the game.
 */
@SuppressWarnings("serial")
public class MainMenu extends JFrame {
    Font font = new Font("Helvetica", Font.PLAIN, 20);

    /**
     * Constructs a new MainMenu.
     * Sets the title, size, default close operation, and layout of the window.
     * Initializes the components of the main menu.
     */
    public MainMenu() {
        setTitle("UNO Game - Main Menu");
        setSize(800, 600);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new BorderLayout());

        JPanel mainPanel = new JPanel();
        mainPanel.setLayout(new BoxLayout(mainPanel, BoxLayout.Y_AXIS));
        mainPanel.setBackground(Color.BLUE);

        SpinnerModel botModel = new SpinnerNumberModel(2, 2, 9, 1);
        JSpinner botSpinner = new JSpinner(botModel);
        botSpinner.setPreferredSize(new Dimension(100, 20));
        JPanel botPanel = createPanel("Select Number of Players:", botSpinner);

        JTextField sessionNameField = new JTextField(20);
        sessionNameField.setFont(font);
        sessionNameField.setPreferredSize(new Dimension(160, 20));
        JPanel sessionPanel = createPanel("Enter the Name of the Session:", sessionNameField);
        sessionNameField.setBackground(Color.white);

        ImageIcon imageIcon = new ImageIcon("src/images/main-menu-img.jpg");
        Image image = imageIcon.getImage();
        Image newImage = image.getScaledInstance(350, 200, java.awt.Image.SCALE_SMOOTH);
        ImageIcon scaledImageIcon = new ImageIcon(newImage);

        JLabel imageLabel = new JLabel(scaledImageIcon);
        imageLabel.setBorder(new EmptyBorder(20, 20, 20, 20));
        botSpinner.setFont(font);
        sessionNameField.setFont(font);

        mainPanel.add(imageLabel);
        mainPanel.add(botPanel);
        mainPanel.add(sessionPanel);

        JButton startButton = new JButton("Start Game");
        startButton.addActionListener(e -> {
            int bots = (Integer) botSpinner.getValue();
            String sessionName = sessionNameField.getText();
            startGame(bots, sessionName);
        });
        startButton.setFont(font);

        JButton leaderboardButton = new JButton("Leaderboard");
        leaderboardButton.setFont(font);
        leaderboardButton.addActionListener(e -> openLeaderboard());

        JButton loadButton = new JButton("Load Game");
        loadButton.setFont(font);
        loadButton.addActionListener(e -> loadGame());

        JPanel lowerPanel = new JPanel();
        lowerPanel.add(startButton);
        lowerPanel.add(leaderboardButton);
        lowerPanel.add(loadButton);
        lowerPanel.setBackground(Color.BLUE);

        add(mainPanel, BorderLayout.CENTER);
        add(lowerPanel, BorderLayout.SOUTH);

        setVisible(true);
    }

    /**
     * Creates a panel with a label and a component.
     *
     * @param labelText the text for the label
     * @param component the component to be added to the panel
     * @return the created JPanel
     */
    private JPanel createPanel(String labelText, Component component) {
        JPanel panel = new JPanel(new FlowLayout(FlowLayout.CENTER, 5, 5));
        var lbl = new JLabel(labelText);
        lbl.setFont(font);
        panel.add(lbl);
        panel.add(component);

        panel.setBackground(Color.cyan);
        return panel;
    }

    /**
     * Starts the game by disposing of the main menu and opening the game window.
     *
     * @param bots        the number of bots selected
     * @param sessionName the name of the game session
     */
    private void startGame(int bots, String sessionName) {
        dispose();
        new GameWindow(bots, sessionName);
    }

    /**
     * Opens the leaderboard frame.
     */
    private void openLeaderboard() {
        new LeaderboardFrame();
        dispose();
    }

    /**
     * Loads a saved game by displaying a list of saved sessions.
     */
    private void loadGame() {
        String[] savedGames = SaveLoadManager.getSavedGames();
        if (savedGames == null || savedGames.length == 0) {
            JOptionPane.showMessageDialog(this, "No saved games found.", "Load Game", JOptionPane.INFORMATION_MESSAGE);
            return;
        }

        String sessionName = (String) JOptionPane.showInputDialog(
                this,
                "Select a session to load:",
                "Load Game",
                JOptionPane.PLAIN_MESSAGE,
                null,
                savedGames,
                savedGames[0]
        );

        if (sessionName != null && !sessionName.isEmpty()) {
            try {
                GameSession gameSession = SaveLoadManager.loadGame(sessionName);
                dispose();
                new GameWindow(gameSession);
            } catch (IOException e) {
                JOptionPane.showMessageDialog(this, "Failed to load game session.", "Error", JOptionPane.ERROR_MESSAGE);
                e.printStackTrace();
            }
        }
    }

    /**
     * The main method to launch the main menu.
     *
     * @param args the command line arguments
     */

}
