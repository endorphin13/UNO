package gui;

import javax.swing.*;

import cards.Card;
import cards.WildCard;
import game.GameSession;
import game.SaveLoadManager;
import gui.utils.ColorPopUp;
import gui.utils.UnoPopUp;
import players.ComputerBot;
import players.HumanPlayer;
import players.Player;

import java.awt.*;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;

/**
 * The main window for the UNO game, managing the game UI and interactions.
 */
@SuppressWarnings("serial")
public class GameWindow extends JFrame {
    private int numberOfPlayers;
    private JLabel currentPlayerLabel;
    private HumanPlayer humanPlayer;
    private GameSession gameSession;
    private Font font = new Font("Helvetica", Font.PLAIN, 20);
    private JPanel humanPlayerPanel;
    private JPanel gamePanel;
    private JPanel botPlayersPanel;
    private JLabel discardPileLabel;
    private JLabel topPileCardColorLabel;
    private JLabel deckCountLabel;
    private JLabel gameDirectionLabel;
    private JButton saveButton;
    private JButton viewLogsButton;

    public static HumanPlayer currentPlayer;

    /**
     * Constructs a new GameWindow.
     *
     * @param numberOfPlayers the number of players in the game
     * @param sessionName     the name of the game session
     */
    public GameWindow(int numberOfPlayers, String sessionName) {
        super(sessionName);

        this.numberOfPlayers = numberOfPlayers;
        setLocationRelativeTo(null);  
        gameSession = new GameSession(sessionName, getPlayers());
        
        initializeUI();
        startGame();
        setLocationRelativeTo(null); 
    }
    
    public GameWindow(GameSession gameSession) {
        super("UNO Game");
        this.gameSession = gameSession;
        this.numberOfPlayers = gameSession.getPlayers().size();
        
        for (Player player : gameSession.getPlayers()) {
            if (player instanceof HumanPlayer) {
                this.humanPlayer = (HumanPlayer) player;
                break;
            }
        }
        
        initializeUI();
        loadGame();
    }
    
    private void loadGame() {
        logMessage("Game started with session name: " + gameSession.getSessionName());
        updateDiscardPileImage(gameSession.getDiscardPileTopCard().getCardImage());
        displayTopPileCardColor(); 
        updateCurrentPlayerLabel();
        paintHumanPlayerPanel();
        paintBotPlayersPanel();
        logMessage("Game loaded successfully.");
        JOptionPane.showMessageDialog(this, "Game loaded successfully.");
        executeTurn();
    }

    /**
     * Starts the game by setting up the initial state and executing the first turn.
     */
    private void startGame() {
        updateDiscardPileImage(gameSession.getDiscardPileTopCard().getCardImage());
        displayTopPileCardColor(); 
        updateCurrentPlayerLabel();
        updateDeckCountLabel(); 
        updateGameDirectionLabel(); 
        try {
            clearLogs("src/files/gameLogs.txt");
        } catch (IOException e) {
            e.printStackTrace();
        }
        executeTurn();
    }

    /**
     * Updates the label displaying the current player's name.
     */
    private void updateCurrentPlayerLabel() {
        Player currentPlayer = gameSession.getPlayers().get(gameSession.getCurrentPlayerIndex());
        currentPlayerLabel.setText("Current Player: " + currentPlayer.getName());
        logMessage("Current Player: " + currentPlayer.getName());
    }

    /**
     * Initializes the list of players for the game session.
     *
     * @return the list of players
     */
    private ArrayList<Player> getPlayers() {
        ArrayList<Player> players = new ArrayList<Player>();
        humanPlayer = currentPlayer;
        players.add(humanPlayer);
        for (int x = 0; x < numberOfPlayers - 1; x++) {
            ComputerBot bot = new ComputerBot("Bot " + (x + 1), false);
            players.add(bot);
        }
        return players;
    }

    /**
     * Initializes the user interface components of the game window.
     */
    private void initializeUI() {
        setTitle("UNO Game");
        setLayout(new BorderLayout(10, 10)); 
        setSize(800, 1000);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        // Top Panel
        JPanel topPanel = new JPanel(new GridLayout(2, 3, 10, 10)); 

        // Label to display the color of the top pile card
        topPileCardColorLabel = new JLabel("Top Pile Card Color: ", SwingConstants.CENTER);
        topPileCardColorLabel.setFont(new Font("Helvetica", Font.BOLD, 18));
        topPanel.add(topPileCardColorLabel);

        // Label to display the number of cards in the deck
        deckCountLabel = new JLabel("Cards in Deck: " + gameSession.getDeck().getCards().size(), SwingConstants.CENTER);
        deckCountLabel.setFont(new Font("Helvetica", Font.BOLD, 18));
        topPanel.add(deckCountLabel);

        // Save Game Button
        saveButton = new JButton("Save Game");
        saveButton.setFont(new Font("Helvetica", Font.BOLD, 18));
        saveButton.addActionListener(e -> saveGame());
        topPanel.add(saveButton);

        // Label to display the game direction
        gameDirectionLabel = new JLabel("Game Direction: Clockwise", SwingConstants.CENTER);
        gameDirectionLabel.setFont(new Font("Helvetica", Font.BOLD, 18));
        topPanel.add(gameDirectionLabel);

        // Label to display the current player's turn
        currentPlayerLabel = new JLabel("Current Player: ", SwingConstants.CENTER);
        currentPlayerLabel.setFont(new Font("Helvetica", Font.BOLD, 18));
        topPanel.add(currentPlayerLabel);

        // Game Logs Button
        viewLogsButton = new JButton("View Game Logs");
        viewLogsButton.setFont(new Font("Helvetica", Font.BOLD, 18));
        viewLogsButton.addActionListener(e -> showGameLogs());
        topPanel.add(viewLogsButton);

        add(topPanel, BorderLayout.NORTH);

        // Center Panel: Game area and bot players
        JPanel centerPanel = new JPanel(new BorderLayout(10, 10)); 

        // Bot Players Panel
        botPlayersPanel = new JPanel(new GridLayout(1, numberOfPlayers - 1, 10, 10)); 
        paintBotPlayersPanel();
        centerPanel.add(botPlayersPanel, BorderLayout.NORTH);

        // Game Area Panel
        gamePanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 10, 10)); 
        paintGamePanel();
        centerPanel.add(gamePanel, BorderLayout.CENTER);

        add(centerPanel, BorderLayout.CENTER);

        // Bottom Panel: Human player's cards
        humanPlayerPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 10, 10)); 
        humanPlayerPanel.setPreferredSize(new Dimension(800, 250));
        paintHumanPlayerPanel();
        add(humanPlayerPanel, BorderLayout.SOUTH);

        setVisible(true);
    }

    private void saveGame() {
        try {
            SaveLoadManager.saveGame(gameSession);
            logMessage("Game saved successfully.");
            JOptionPane.showMessageDialog(this, "Game saved successfully.");
            dispose();
            new MainMenu();
        } catch (IOException e) {
            logMessage("Failed to save the game.");
            JOptionPane.showMessageDialog(this, "Failed to save the game.", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    /**
     * Updates the panel displaying the number of cards in the Deck.
     */
    private void updateDeckCountLabel() {
        deckCountLabel.setText("Cards in Deck: " + gameSession.getDeck().getCards().size());
    }

    /**
     * Updates the panel displaying the direction of the game.
     */
    private void updateGameDirectionLabel() {
        gameDirectionLabel.setText("Game Direction: " + (gameSession.isClockwise() ? "Clockwise" : "Counterclockwise"));
    }

    /**
     * Updates the panel displaying the human player's cards.
     */
    private void paintHumanPlayerPanel() {
        humanPlayerPanel.removeAll();
        humanPlayerPanel.setBackground(Color.LIGHT_GRAY);
        Player player = gameSession.getPlayers().get(0);
        JPanel playersCardsPanel = new JPanel();
        for (Card card : player.getPlayerCards()) {
            JButton cardButton = new JButton();
            ImageIcon icon = new ImageIcon(card.getCardImage());
            Image image = icon.getImage().getScaledInstance(70, 120, Image.SCALE_SMOOTH);
            cardButton.setIcon(new ImageIcon(image));
            cardButton.addActionListener(e -> playCard(card));
            playersCardsPanel.add(cardButton);
        }
        humanPlayerPanel.add(playersCardsPanel);
        humanPlayerPanel.revalidate();
        humanPlayerPanel.repaint();
    }

    /**
     * Updates the panel displaying the game area.
     */
    private void paintGamePanel() {
        gamePanel.removeAll();
        JButton drawPileButton = new JButton();
        String imagePath = "src/images/draw-pile.png";
        ImageIcon drawPileIcon = new ImageIcon(imagePath);
        Image scaledImage = drawPileIcon.getImage().getScaledInstance(90, 120, Image.SCALE_SMOOTH);
        drawPileIcon = new ImageIcon(scaledImage);
        drawPileButton.setIcon(drawPileIcon);
        drawPileButton.addActionListener(e -> drawCard());
        gamePanel.add(drawPileButton);

        discardPileLabel = new JLabel();
        discardPileLabel.setBorder(BorderFactory.createLineBorder(Color.BLACK));
        updateDiscardPileImage("src/images/empty.png");
        gamePanel.add(discardPileLabel);
    }

    /**
     * Updates the panel displaying the bot players' cards.
     */
    private void paintBotPlayersPanel() {
        botPlayersPanel.removeAll();
        for (int i = 1; i < numberOfPlayers; i++) {
            Panel botPanel = new Panel();
            botPanel.setLayout(new BorderLayout());

            JLabel cardImageLabel = new JLabel();
            ImageIcon icon = new ImageIcon("src/images/default-card-image.jpg");
            Image image = icon.getImage().getScaledInstance(70, 120, Image.SCALE_SMOOTH);
            cardImageLabel.setIcon(new ImageIcon(image));

            JLabel cardCountLabel = new JLabel(
                    Integer.toString(gameSession.getPlayers().get(i).getPlayerCards().size()) + " cards");
            cardCountLabel.setAlignmentX(CENTER_ALIGNMENT);
            cardCountLabel.setFont(font);
            botPanel.add(cardImageLabel, BorderLayout.CENTER);
            botPanel.add(cardCountLabel, BorderLayout.SOUTH);

            botPlayersPanel.setBackground(Color.LIGHT_GRAY);
            botPlayersPanel.add(botPanel);
        }
    }

    /**
     * Updates the image of the discard pile.
     *
     * @param imagePath the path to the image file
     */
    private void updateDiscardPileImage(String imagePath) {
        ImageIcon discardPileIcon = new ImageIcon(imagePath);
        Image scaledImage = discardPileIcon.getImage().getScaledInstance(100, 150, Image.SCALE_SMOOTH);
        discardPileIcon = new ImageIcon(scaledImage);
        discardPileLabel.setIcon(discardPileIcon);
        discardPileLabel.revalidate();
        discardPileLabel.repaint();
    }

    /**
     * Checks if the current bot needs to call UNO and handles it accordingly.
     */
    private void checkUnoCallForBot(Player bot) {
        if (bot.getPlayerCards().size() == 1) {
            logMessage(bot.getName() + " calls UNO!");
            JOptionPane.showMessageDialog(this, bot.getName() + " calls UNO!");
        }
    }

    /**
     * Plays a card and updates the game state accordingly.
     *
     * @param card the card to be played
     */
    private void playCard(Card card) {
        if (gameSession.getCurrentPlayerIndex() == 0) {
            if (gameSession.isValidPlay(card)) {
                logMessage("Card played: " + card + " by " + humanPlayer.getName());
                if (card instanceof WildCard) {
                    ColorPopUp colorSelectionPopup = new ColorPopUp(this);
                    colorSelectionPopup.setVisible(true);
                    String selectedColor = colorSelectionPopup.getSelectedColor();
                    gameSession.setPileColor(selectedColor);
                    logMessage("WildCard color selected: " + selectedColor);
                }

                gameSession.executeCardPlay(card, humanPlayer);
                updateDiscardPileImage(card.getCardImage());
                displayTopPileCardColor();

                if (humanPlayer.getPlayerCards().size() == 1) {
                    UnoPopUp unoPopUp = new UnoPopUp(this);
                    unoPopUp.setVisible(true);
                    if (!unoPopUp.isUnoCalled()) {
                        Card penaltyCard1 = gameSession.getDeck().draw();
                        Card penaltyCard2 = gameSession.getDeck().draw();
                        humanPlayer.addCardToHand(penaltyCard1);
                        humanPlayer.addCardToHand(penaltyCard2);
                        paintHumanPlayerPanel();
                        logMessage("Penalty cards added for failing to call UNO: " + penaltyCard1 + " " + penaltyCard2);
                        JOptionPane.showMessageDialog(this, "You failed to call UNO! Two penalty cards has been added.");
                    } else {
                        logMessage("UNO called by " + humanPlayer.getName());
                        JOptionPane.showMessageDialog(this, "You called UNO!");
                    }
                }

                paintHumanPlayerPanel();
                checkGameEnd();
                nextTurn();
            } else {
                logMessage("Invalid move! Please select a valid card.");
                JOptionPane.showMessageDialog(this, "Invalid move! Please select a valid card.");
            }
        } else {
            logMessage("It's not your turn!");
            JOptionPane.showMessageDialog(this, "It's not your turn!");
        }
    }

    /**
     * Advances to the next turn, handling any skipped turns if necessary.
     */
    private void nextTurn() {
        if (!gameSession.isGameActive()) {
            displayWinner();
            return;
        }

        gameSession.nextPlayer();
        updateCurrentPlayerLabel();
        logMessage("Next turn. Current player index: " + gameSession.getCurrentPlayerIndex());

        if (gameSession.isNextPlayerSkipTurn()) {
            gameSession.setNextPlayerSkipTurn(false);
            gameSession.nextPlayer();
            logMessage("Player turn skipped. New current player index: " + gameSession.getCurrentPlayerIndex());
        }

        SwingUtilities.invokeLater(this::executeTurn);
    }
    /**
     * Executes the current player's turn, including handling bot actions.
     */
    private void executeTurn() {
        Player currentPlayer = gameSession.getPlayers().get(gameSession.getCurrentPlayerIndex());
        logMessage("Executing turn for player: " + currentPlayer.getName());
        if (currentPlayer.isHuman()) {
            paintHumanPlayerPanel();
        } else {
            javax.swing.Timer timer = new javax.swing.Timer(3000, e -> {
                Card cardToPlay = gameSession.getPlayableCardForCurrentPlayer();
                if (cardToPlay != null) {
                    logMessage("Bot " + currentPlayer.getName() + " plays card: " + cardToPlay);
                    gameSession.executeCardPlay(cardToPlay, currentPlayer);
                    updateDiscardPileImage(cardToPlay.getCardImage());
                    displayTopPileCardColor();
                    checkUnoCallForBot(currentPlayer);
                    checkGameEnd();
                    paintBotPlayersPanel();
                    updateDeckCountLabel();
                    updateGameDirectionLabel();
                    nextTurn();
                } else {
                    drawCardForBot(currentPlayer);
                }
            });
            timer.setRepeats(false);
            timer.start();
        }
    }

    /**
     * Handles the action of a bot drawing a card and attempting to play it.
     *
     * @param bot the bot player
     */
    private void drawCardForBot(Player bot) {
        if (gameSession.getDeck().getCards().size() == 0) {
            gameSession.replenishDeckFromDiscardPile();
        }
        Card drawnCard;
        boolean validPlayFound = false;

        do {
            drawnCard = gameSession.getDeck().draw();
            if (drawnCard != null) {
                bot.getPlayerCards().add(drawnCard);
                logMessage(bot.getName() + " draws card: " + drawnCard);
                if (gameSession.isValidPlay(drawnCard)) {
                    gameSession.executeCardPlay(drawnCard, bot);
                    updateDiscardPileImage(drawnCard.getCardImage());
                    displayTopPileCardColor();
                    validPlayFound = true;
                    logMessage(bot.getName() + " plays card: " + drawnCard);
                } else {
                    logMessage(bot.getName() + " cannot play drawn card: " + drawnCard);
                }
            } else {
                break;
            }
        } while (!validPlayFound);

        checkGameEnd();
        updateDeckCountLabel();
        updateGameDirectionLabel();

        nextTurn();
    }


    /**
     * Handles the action of a human player drawing a card and attempting to play it.
     */
    private void drawCard() {
        if (gameSession.getDeck().getCards().size() == 0) {
            gameSession.replenishDeckFromDiscardPile();
        }

        if (gameSession.getCurrentPlayerIndex() == 0) {
            Player player = gameSession.getPlayers().get(gameSession.getCurrentPlayerIndex());
            Card drawnCard;
            boolean validPlayFound = false;

            do {
                drawnCard = gameSession.getDeck().draw();
                if (drawnCard != null) {
                    logMessage("You drew a card: " + drawnCard);
                    JOptionPane.showMessageDialog(this, "You drew a card: " + drawnCard);
                    player.getPlayerCards().add(drawnCard);
                    paintHumanPlayerPanel();
                    updateDeckCountLabel();

                    if (gameSession.isValidPlay(drawnCard)) {
                        validPlayFound = true;
                        logMessage("Playable card drawn: " + drawnCard);
                    }
                } else {
                    logMessage("No more cards in the deck to draw!");
                    JOptionPane.showMessageDialog(this, "No more cards in the deck to draw!", "Draw Pile Empty", JOptionPane.WARNING_MESSAGE);
                    break;
                }
            } while (!validPlayFound);

            if (validPlayFound) {
                logMessage("You drew a playable card: " + drawnCard);
                JOptionPane.showMessageDialog(this, "You drew a playable card: " + drawnCard);
            } else {
                nextTurn();
            }
        } else {
            logMessage("It's not your turn to draw a card!");
            JOptionPane.showMessageDialog(this, "It's not your turn to draw a card!");
        }
    }


    /**
     * Checks if the game has ended and determines the winner if so.
     */
    private void checkGameEnd() {
        gameSession.determineWinner();
        if (gameSession.getWinner() != null) {
            gameSession.setGameActive(false);
            humanPlayer.getPlayerCards().clear();
            updatePlayerStatistics();
            logMessage("Game ended. Winner: " + gameSession.getWinner().getName());
            dispose();
            new MainMenu();
        }
    }

    /**
     * Displays the winner of the game.
     */
    private void displayWinner() {
        Player winner = gameSession.getWinner();
        if (winner != null) {
            logMessage("The winner is: " + winner.getName());
            JOptionPane.showMessageDialog(this, "The winner is: " + winner.getName(), "Game Over", JOptionPane.INFORMATION_MESSAGE);
        }
    }

    /**
     * Sets a random color if the top card is a WildCard and the current player is a bot.
     */
    @SuppressWarnings("unused") //used but not directly
    private void setColorIfNone() {
        Card topCard = gameSession.getDiscardPileTopCard();
        Player currentPlayer = gameSession.getPlayers().get(gameSession.getCurrentPlayerIndex());

        if (topCard instanceof WildCard && currentPlayer instanceof ComputerBot) {
            String[] colors = {"Red", "Green", "Blue", "Yellow"};
            String randomColor = colors[(int) (Math.random() * colors.length)];
            gameSession.setPileColor(randomColor);
            displayTopPileCardColor(); 
            updateCurrentPlayerLabel();
        }
    }

    /**
     * Displays the color of the top card on the pile.
     */
    private void displayTopPileCardColor() {
        Card topCard = gameSession.getDiscardPileTopCard();
        String colorName;

        if (topCard instanceof WildCard) {
            colorName = gameSession.getPileColor();
        } else {
            colorName = topCard.getColor().toString();
        }

        topPileCardColorLabel.setText("Top Pile Card Color: " + colorName);
    }

    /**
     * Updates the statistics after the game is ended.
     */
    private void updatePlayerStatistics() {
        File csvFile = new File("src/files/userStatistics.csv");
        if (!csvFile.exists()) {
            JOptionPane.showMessageDialog(this, "Statistics file not found.", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        ArrayList<String[]> playerData = new ArrayList<>();
        String[] headers = null;

        try (BufferedReader br = new BufferedReader(new FileReader(csvFile))) {
            String line = br.readLine();
            if (line != null) {
                headers = line.split(",");
            }

            while ((line = br.readLine()) != null) {
                String[] data = line.split(",");
                playerData.add(data);
            }
        } catch (IOException e) {
            e.printStackTrace();
            return;
        }

        Player winner = gameSession.getWinner();
        for (String[] player : playerData) {
            if (player[0].equals(humanPlayer.getName())) {
                int gamesPlayed = Integer.parseInt(player[1]);
                int wins = Integer.parseInt(player[2]);
                int losses = Integer.parseInt(player[3]);
                int totalScore = Integer.parseInt(player[4]);
                double averageScore = Double.parseDouble(player[5]);
                double winLossRatio = Double.parseDouble(player[6]);

                gamesPlayed++;

                if (humanPlayer.equals(winner)) {
                    wins++;
                    totalScore += humanPlayer.getScore();
                } else {
                    losses++;
                }

                averageScore = (double) totalScore / gamesPlayed;
                winLossRatio = (double) wins / losses;

                player[1] = String.valueOf(gamesPlayed);
                player[2] = String.valueOf(wins);
                player[3] = String.valueOf(losses);
                player[4] = String.valueOf(totalScore);
                player[5] = String.format("%.2f", averageScore);
                player[6] = String.format("%.2f", winLossRatio);
            }
        }

        try (PrintWriter pw = new PrintWriter(new BufferedWriter(new FileWriter(csvFile)))) {
            if (headers != null) {
                pw.println(String.join(",", headers));
            }
            for (String[] player : playerData) {
                pw.println(String.join(",", player));
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }


    /**
     * Logs a message to the gameLogs.txt file.
     *
     * @param message the message to log
     */
    private synchronized void logMessage(String message) {
        try (PrintWriter out = new PrintWriter(new BufferedWriter(new FileWriter("src/files/gameLogs.txt", true)))) {
            out.println(message);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }



    /**
     * Displays the game logs in a new frame.
     */
    private void showGameLogs() {
        JFrame logFrame = new JFrame("Game Logs");
        logFrame.setSize(500, 500);
        logFrame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

        JTextArea logTextArea = new JTextArea();
        logTextArea.setEditable(false);

        try (BufferedReader br = new BufferedReader(new FileReader("src/files/gameLogs.txt"))) {
            String line;
            while ((line = br.readLine()) != null) {
                logTextArea.append(line + "\n");
            }
        } catch (IOException e) {
            logTextArea.setText("Failed to load logs.");
        }

        JScrollPane scrollPane = new JScrollPane(logTextArea);
        logFrame.add(scrollPane);
        logFrame.setVisible(true);
    }

    public static void clearLogs(String filePath) throws IOException {
        try (FileWriter fileWriter = new FileWriter(filePath, false)) {
            fileWriter.write("");
        }
    }
}
