package gui;

import javax.swing.*;
import java.awt.*;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.Arrays;

/**
 * The UserDetailsFrame class represents a window that displays user details.
 * It reads user data from a CSV file and shows the details for a given player.
 */
@SuppressWarnings("serial")
public class UserDetailsFrame extends JFrame {

    /**
     * Constructs a new UserDetailsFrame for the specified player.
     *
     * @param playerName the name of the player whose details are to be displayed
     */
    public UserDetailsFrame(String playerName) {
        setTitle("User Details - " + playerName);
        setSize(800, 500);  
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        
        setLayout(new BorderLayout());
        JPanel detailsPanel = new JPanel(new GridLayout(0, 1));  
        detailsPanel.setBackground(new Color(0, 84, 147));  
        add(detailsPanel, BorderLayout.CENTER);

        String[][] dataAndHeaders = getPlayerDataAndHeaders(playerName);
        if (dataAndHeaders == null || dataAndHeaders[0] == null || dataAndHeaders[1] == null) {
            detailsPanel.add(new JLabel("Player data not found.", JLabel.CENTER));
            setVisible(true);
            return;
        }

        String[] headers = dataAndHeaders[0];
        String[] playerData = dataAndHeaders[1];

        JButton backButton = new JButton("<");
        backButton.addActionListener(e -> dispose());
        add(backButton, BorderLayout.NORTH);

        for (int i = 0; i < headers.length; i++) {
            JLabel label = new JLabel(headers[i] + ": " + playerData[i], JLabel.CENTER);
            label.setForeground(Color.WHITE); 
            detailsPanel.add(label);
        }

        setVisible(true);
    }

    /**
     * Retrieves player data and headers from the CSV file for the specified player.
     *
     * @param playerName the name of the player whose data is to be retrieved
     * @return a 2D array containing headers and player data, or null if data is not found
     */
    private String[][] getPlayerDataAndHeaders(String playerName) {
        try (BufferedReader br = new BufferedReader(new FileReader("src/files/userStatistics.csv"))) {
            String line = br.readLine();  
            if (line == null) return null;
            String[] headers = line.split(",");
            while ((line = br.readLine()) != null) {
                String[] data = line.split(",");
                if (data[0].equalsIgnoreCase(playerName)) {
                    return new String[][]{headers, Arrays.copyOfRange(data, 0, data.length)};
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        return null;
    }

    /**
     * The main method to launch the UserDetailsFrame.
     *
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new UserDetailsFrame("Alice"));
    }
}
