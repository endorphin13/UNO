package gui;

import javax.imageio.ImageIO;
import javax.swing.*;

import gui.utils.GradientPanel;
import gui.utils.PlaceHolderPasswordField;
import gui.utils.PlaceHolderTextField;
import players.HumanPlayer;

import java.awt.*;
import java.awt.event.*;
import java.awt.image.BufferedImage;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;

/**
 * The LoginPage class represents the login window for the UNO game application.
 * It provides a user interface for users to enter their nickname and password to log in or register a new account.
 */
@SuppressWarnings("serial")
public class LoginPage extends JFrame {
    private PlaceHolderTextField usernameField;
    private PlaceHolderPasswordField passwordField;
    private JButton loginButton;
    private JButton registerButton;
    private JLabel logoLabel;

    /**
     * Constructs a new LoginPage.
     * Sets the title, size, default close operation, and content pane of the window.
     * Initializes the components of the login page.
     */
    public LoginPage() {
        setTitle("Login - UNO Game");
        setSize(800, 500);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setContentPane(new GradientPanel()); 
        getContentPane().setLayout(null);

        initializeComponents();
    }

    /**
     * Initializes the components of the login page, including the logo, username and password fields, and login and register buttons.
     */
    private void initializeComponents() {
        try {
            BufferedImage originalImage = ImageIO.read(new File("src/images/uno-logo.png"));
            int scaledWidth = 300;
            int scaledHeight = 150;
            Image scaledImage = originalImage.getScaledInstance(scaledWidth, scaledHeight, Image.SCALE_SMOOTH);
            logoLabel = new JLabel(new ImageIcon(scaledImage));
            logoLabel.setBounds(50, 120, scaledWidth, scaledHeight);
            getContentPane().add(logoLabel);
        } catch (IOException e) {
            e.printStackTrace();
            System.out.println("Error loading or scaling logo image.");
        }

        try {
            BufferedImage userIcon = ImageIO.read(new File("src/images/login_icon.png"));
            JLabel userIconLabel = new JLabel(new ImageIcon(userIcon.getScaledInstance(24, 24, Image.SCALE_SMOOTH)));
            userIconLabel.setBounds(362, 100, 30, 30);
            getContentPane().add(userIconLabel);
        } catch (IOException e) {
            e.printStackTrace();
            System.out.println("Error loading username icon.");
        }

        usernameField = new PlaceHolderTextField("Nickname");
        usernameField.setBounds(400, 100, 250, 30);
        getContentPane().add(usernameField);

        try {
            BufferedImage passIcon = ImageIO.read(new File("src/images/password_icon.png"));
            JLabel passIconLabel = new JLabel(new ImageIcon(passIcon.getScaledInstance(24, 24, Image.SCALE_SMOOTH)));
            passIconLabel.setBounds(362, 150, 30, 30);
            getContentPane().add(passIconLabel);
        } catch (IOException e) {
            e.printStackTrace();
            System.out.println("Error loading password icon.");
        }

        // Password Field
        passwordField = new PlaceHolderPasswordField("Password");
        passwordField.setBounds(400, 150, 250, 30);
        getContentPane().add(passwordField);

        // Login Button
        loginButton = new JButton("Login");
        loginButton.setBounds(397, 240, 115, 30);
        loginButton.addActionListener(this::loginAction);
        getContentPane().add(loginButton);

        // Register Button
        registerButton = new JButton("Register");
        registerButton.setBounds(535, 240, 115, 30);
        registerButton.addActionListener(this::registerAction);
        getContentPane().add(registerButton);

        setVisible(true);
    }

    /**
     * Handles the login action. Validates the username and password fields and checks the credentials.
     * If the credentials are valid, opens the main menu; otherwise, shows an error message.
     * 
     * @param event the action event triggered by clicking the login button
     */
    private void loginAction(ActionEvent event) {
        String username = usernameField.getText().trim();
        String password = new String(passwordField.getPassword()).trim();

        if (username.isBlank() || password.isBlank()) {
            JOptionPane.showMessageDialog(this, "The nickname or password fields are empty!", "Login Failed", JOptionPane.ERROR_MESSAGE);
        } else if (validateCredentials(username, password)) {
            JOptionPane.showMessageDialog(this, "Login Successful!", "Success", JOptionPane.INFORMATION_MESSAGE);
            this.dispose();
            GameWindow.currentPlayer = new HumanPlayer(username, true);

            new MainMenu(); 
        } else {
            JOptionPane.showMessageDialog(this, "Invalid username or password!", "Login Failed", JOptionPane.ERROR_MESSAGE);
        }
    }

    /**
     * Validates the credentials by checking the username and password against a CSV file.
     * 
     * @param username the username entered by the user
     * @param password the password entered by the user
     * @return true if the credentials are valid, false otherwise
     */
    private boolean validateCredentials(String username, String password) {
        File csvFile = new File("src/files/data.csv");
        if (csvFile.isFile()) {
            try (BufferedReader br = new BufferedReader(new FileReader(csvFile))) {
                String line;
                while ((line = br.readLine()) != null) {
                    String[] data = line.split(",");
                    if (data.length == 2 && data[0].equals(username) && data[1].equals(password)) {
                        return true; 
                    }
                }
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
        return false; 
    }

    /**
     * Handles the register action. Opens the registration page.
     * 
     * @param event the action event triggered by clicking the register button
     */
    private void registerAction(ActionEvent event) {
        dispose(); 
        new RegistrationPage();
    }

    /**
     * The main method to launch the login page.
     * 
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        SwingUtilities.invokeLater(LoginPage::new);
    }
}
