package gui;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import gui.utils.GradientPanel;
import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;

/**
 * Represents a leaderboard frame displaying player rankings.
 */
@SuppressWarnings("serial")
public class LeaderboardFrame extends JFrame {

    /**
     * Constructs the LeaderboardFrame.
     */
    public LeaderboardFrame() {
        setTitle("Leaderboard");
        setSize(800, 500);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        GradientPanel gradientPanel = new GradientPanel();
        setContentPane(gradientPanel);
        gradientPanel.setLayout(new BorderLayout());

        String[][] data = readPlayersFromCSV("src/files/userStatistics.csv");
        String[] columnNames = {"Rank", "Player Name", "Total Score"};

        DefaultTableModel model = new DefaultTableModel(data, columnNames) {
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };

        JTable table = new JTable(model);
        table.setRowHeight(20);

        table.addMouseListener(new MouseAdapter() {
            public void mouseClicked(MouseEvent e) {
                int row = table.rowAtPoint(e.getPoint());
                int column = table.columnAtPoint(e.getPoint());
                if (column == 1) {
                    String playerName = (String) table.getValueAt(row, column);
                    new UserDetailsFrame(playerName);
                }
            }
        });

        JScrollPane scrollPane = new JScrollPane(table);
        scrollPane.getViewport().setOpaque(false);
        scrollPane.setOpaque(false);
        gradientPanel.add(scrollPane, BorderLayout.CENTER);

        JButton backButton = new JButton("Back to Main Menu");
        backButton.setFont(new Font("Helvetica", Font.PLAIN, 20));
        backButton.addActionListener(e -> openMainMenu());

        JPanel lowerPanel = new JPanel();
        lowerPanel.add(backButton);
        lowerPanel.setBackground(Color.WHITE);

        gradientPanel.add(lowerPanel, BorderLayout.SOUTH);

        setVisible(true);
    }

    /**
     * Opens the main menu by disposing of the current frame and creating a new MainMenu instance.
     */
    private void openMainMenu() {
        dispose();
        new MainMenu();
    }

    /**
     * Reads player data from a CSV file and returns it sorted by total score in descending order.
     * 
     * @param fileName the path to the CSV file containing the player data
     * @return a two-dimensional String array containing player names and scores
     */
    private String[][] readPlayersFromCSV(String fileName) {
        ArrayList<String[]> players = new ArrayList<>();
        try (BufferedReader br = new BufferedReader(new FileReader(fileName))) {
            br.readLine(); 
            String line;
            while ((line = br.readLine()) != null) {
                String[] attributes = line.split(",");
                players.add(new String[]{attributes[0], attributes[4]});
            }
        } catch (IOException e) {
            e.printStackTrace();
        }

        players.sort((a, b) -> Integer.compare(Integer.parseInt(b[1]), Integer.parseInt(a[1])));

        String[][] data = new String[players.size()][3];
        for (int i = 0; i < players.size(); i++) {
            data[i][0] = String.valueOf(i + 1);
            data[i][1] = players.get(i)[0];
            data[i][2] = players.get(i)[1];
        }

        return data;
    }

    /**
     * Main method to launch the application.
     * 
     * @param args command line arguments (unused)
     */
    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new LeaderboardFrame());
    }
}
