package gui.utils;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

/**
 * A popup dialog for selecting a color in the UNO game.
 */
@SuppressWarnings("serial")
public class ColorPopUp extends JDialog {
    private String selectedColor;

    /**
     * Constructs a new ColorPopUp dialog.
     *
     * @param parent the parent frame of this dialog
     */
    public ColorPopUp(JFrame parent) {
        super(parent, "Choose Color", true);
        setSize(300, 150);
        setLocationRelativeTo(parent);
        setLayout(new GridLayout(2, 2));
        
        
        JButton blueButton = new JButton("Blue");
        JButton greenButton = new JButton("Green");
        JButton redButton = new JButton("Red");
        JButton yellowButton = new JButton("Yellow");

        redButton.addActionListener(new ColorButtonListener("Red"));
        blueButton.addActionListener(new ColorButtonListener("Blue"));
        greenButton.addActionListener(new ColorButtonListener("Green"));
        yellowButton.addActionListener(new ColorButtonListener("Yellow"));

        add(redButton);
        add(blueButton);
        add(greenButton);
        add(yellowButton);
    }

    /**
     * Returns the selected color.
     *
     * @return the selected color
     */
    public String getSelectedColor() {
        return selectedColor;
    }

    /**
     * An ActionListener for color buttons in the ColorPopUp dialog.
     */
    private class ColorButtonListener implements ActionListener {
        private String color;

        /**
         * Constructs a new ColorButtonListener.
         *
         * @param color the color associated with this button listener
         */
        public ColorButtonListener(String color) {
            this.color = color;
        }

        @Override
        public void actionPerformed(ActionEvent e) {
            selectedColor = color;
            dispose();
        }
    }
}
