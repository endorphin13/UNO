package gui.utils;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

/**
 * A popup dialog for calling UNO in the UNO game.
 */
@SuppressWarnings("serial")
public class UnoPopUp extends JDialog {
    private boolean unoCalled;

    /**
     * Constructs a new UnoPopUp dialog.
     *
     * @param parent the parent frame of this dialog
     */
    public UnoPopUp(JFrame parent) {
        super(parent, "Call UNO!", true);
        setSize(300, 150);
        setLocationRelativeTo(parent);
        setLayout(new BorderLayout());

        JLabel promptLabel = new JLabel("Press UNO!", SwingConstants.CENTER);
        promptLabel.setFont(new Font("Helvetica", Font.BOLD, 18));
        add(promptLabel, BorderLayout.CENTER);

        JButton unoButton = new JButton("UNO!");
        unoButton.setFont(new Font("Helvetica", Font.BOLD, 18));
        unoButton.addActionListener(new UnoButtonListener());

        JPanel buttonPanel = new JPanel();
        buttonPanel.add(unoButton);
        add(buttonPanel, BorderLayout.SOUTH);

        Timer timer = new Timer(5000, new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if (!unoCalled) {
                    dispose();
                }
            }
        });
        timer.setRepeats(false);
        timer.start();
    }

    /**
     * Checks if UNO was called.
     *
     * @return true if UNO was called, false otherwise
     */
    public boolean isUnoCalled() {
        return unoCalled;
    }

    /**
     * An ActionListener for the UNO button in the UnoPopUp dialog.
     */
    private class UnoButtonListener implements ActionListener {
        @Override
        public void actionPerformed(ActionEvent e) {
            unoCalled = true;
            dispose();
        }
    }
}
