package gui.utils;

import javax.swing.*;
import java.awt.*;
import java.awt.event.FocusAdapter;
import java.awt.event.FocusEvent;

/**
 * A custom JTextField that displays placeholder text when the field is empty and unfocused.
 * The placeholder text disappears when the field gains focus and reappears when it loses focus and is empty.
 */
@SuppressWarnings("serial")
public class PlaceHolderTextField extends JTextField {
    private String placeholder;

    /**
     * Constructs a PlaceHolderTextField with the specified placeholder text.
     *
     * @param placeholder the placeholder text to display when the field is empty and unfocused
     */
    public PlaceHolderTextField(String placeholder) {
        super(placeholder);
        this.setPlaceholder(placeholder);
        setForeground(Color.GRAY);
        addFocusListener(new FocusAdapter() {

            /**
             * Called when the component gains focus. If the current text matches the placeholder,
             * it clears the text and changes the text color to black.
             *
             * @param e the focus event
             */
            @Override
            public void focusGained(FocusEvent e) {
                if (getText().equals(placeholder)) {
                    setText("");
                    setForeground(Color.BLACK);
                }
            }

            /**
             * Called when the component loses focus. If the current text is empty,
             * it sets the text to the placeholder and changes the text color to gray.
             *
             * @param e the focus event
             */
            @Override
            public void focusLost(FocusEvent e) {
                if (getText().isEmpty()) {
                    setText(placeholder);
                    setForeground(Color.GRAY);
                }
            }
        });
    }

	public String getPlaceholder() {
		return placeholder;
	}

	public void setPlaceholder(String placeholder) {
		this.placeholder = placeholder;
	}
}
