package gui.utils;

import java.awt.Color;
import java.awt.event.FocusAdapter;
import java.awt.event.FocusEvent;
import javax.swing.JPasswordField;

/**
 * A custom JPasswordField that displays a placeholder text when the field is empty and unfocused.
 * The placeholder text disappears when the field gains focus and reappears when it loses focus and is empty.
 */
@SuppressWarnings("serial")
public class PlaceHolderPasswordField extends JPasswordField {
    private String placeholder;

    /**
     * Constructs a PlaceHolderPasswordField with the specified placeholder text.
     *
     * @param placeholder the placeholder text to display when the field is empty and unfocused
     */
    public PlaceHolderPasswordField(String placeholder) {
        super(placeholder);
        this.setPlaceholder(placeholder);
        setEchoChar((char) 0);
        setForeground(Color.GRAY);
        addFocusListener(new FocusAdapter() {

            /**
             * Called when the component gains focus. If the current text matches the placeholder,
             * it clears the text, sets the echo character for password input, and changes the text color to black.
             *
             * @param e the focus event
             */
            @Override
            public void focusGained(FocusEvent e) {
                if (String.valueOf(getPassword()).equals(placeholder)) {
                    setText("");
                    setEchoChar('●');
                    setForeground(Color.BLACK);
                }
            }

            /**
             * Called when the component loses focus. If the current text is empty,
             * it sets the text to the placeholder, removes the echo character, and changes the text color to gray.
             *
             * @param e the focus event
             */
            @Override
            public void focusLost(FocusEvent e) {
                if (String.valueOf(getPassword()).isEmpty()) {
                    setText(placeholder);
                    setEchoChar((char) 0);
                    setForeground(Color.GRAY);
                }
            }
        });
    }

	public String getPlaceholder() {
		return placeholder;
	}

	public void setPlaceholder(String placeholder) {
		this.placeholder = placeholder;
	}
}
