package gui.utils;

import java.awt.Color;
import java.awt.GradientPaint;
import java.awt.Graphics;
import java.awt.Graphics2D;
import javax.swing.JPanel;

/**
 * GradientPanel is a custom JPanel that displays a gradient background.
 * The gradient transitions from red to a gray color.
 */
@SuppressWarnings("serial")
public class GradientPanel extends JPanel {

    /**
     * Paints the component with a gradient background.
     *
     * @param g the Graphics object used to paint the component
     */
    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        Graphics2D g2d = (Graphics2D) g;
        int width = getWidth();
        int height = getHeight();
        Color color1 = new Color(255, 0, 0);  // Red
        Color color2 = new Color(170, 170, 170);  // Gray
        GradientPaint gp = new GradientPaint(0, 0, color1, width, height, color2);
        g2d.setPaint(gp);
        g2d.fillRect(0, 0, width, height);
    }
}
