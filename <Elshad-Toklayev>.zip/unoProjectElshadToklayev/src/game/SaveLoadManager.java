package game;

import cards.*;
import players.*;

import java.io.*;
import java.util.ArrayList;
import java.util.List;

/**
 * A class to manage saving and loading the game state.
 */
public class SaveLoadManager {
    private static final String SAVE_FILE_PATH = "src/files/savedGames/";

    /**
     * Saves the current game state to a file.
     *
     * @param gameSession the current game session
     * @throws IOException if an I/O error occurs
     */
    public static void saveGame(GameSession gameSession) throws IOException {
        File folder = new File(SAVE_FILE_PATH);
        if (!folder.exists()) {
            folder.mkdirs();
        }

        try (BufferedWriter writer = new BufferedWriter(new FileWriter(SAVE_FILE_PATH + gameSession.getSessionName() + ".txt"))) {
            writer.write(gameSession.getCurrentPlayerIndex() + "\n");
            writer.write(gameSession.isClockwise() + "\n");
            writer.write(gameSession.getPileColor() + "\n");

            for (Player player : gameSession.getPlayers()) {
                writer.write(player.getName() + "," + player.isHuman() + "\n");
                for (Card card : player.getPlayerCards()) {
                    writer.write(card.getColor() + "," + card.getValue() + "," + card.getClass().getSimpleName());
                    if (card instanceof ActionCard) {
                        writer.write("," + ((ActionCard) card).getActionType().toString());
                    } else if (card instanceof WildCard) {
                        writer.write("," + ((WildCard) card).getWildType().toString());
                    }
                    writer.write("\n");
                }
                writer.write("END_PLAYER_CARDS\n");
            }

            writer.write("DISCARD_PILE\n");
            for (Card card : gameSession.getDiscardPile()) {
                writer.write(card.getColor() + "," + card.getValue() + "," + card.getClass().getSimpleName());
                if (card instanceof ActionCard) {
                    writer.write("," + ((ActionCard) card).getActionType().toString());
                } else if (card instanceof WildCard) {
                    writer.write("," + ((WildCard) card).getWildType().toString());
                }
                writer.write("\n");
            }
            writer.write("END_DISCARD_PILE\n");

            writer.write("DECK\n");
            for (Card card : gameSession.getDeck().getCards()) {
                writer.write(card.getColor() + "," + card.getValue() + "," + card.getClass().getSimpleName());
                if (card instanceof ActionCard) {
                    writer.write("," + ((ActionCard) card).getActionType().toString());
                } else if (card instanceof WildCard) {
                    writer.write("," + ((WildCard) card).getWildType().toString());
                }
                writer.write("\n");
            }
            writer.write("END_DECK\n");
        }
    }

    /**
     * Loads the game state from a file.
     *
     * @param sessionName the name of the session to load
     * @return the loaded game session
     * @throws IOException if an I/O error occurs
     */
    public static GameSession loadGame(String sessionName) throws IOException {
        List<Player> players = new ArrayList<>();
        List<Card> discardPile = new ArrayList<>();
        List<Card> deckCards = new ArrayList<>();
        Deck deck;
        int currentPlayerIndex;
        boolean isClockwise;
        String pileColor;
        Card discardPileTopCard = null;

        try (BufferedReader reader = new BufferedReader(new FileReader(SAVE_FILE_PATH + sessionName ))) {
            currentPlayerIndex = Integer.parseInt(reader.readLine());
            isClockwise = Boolean.parseBoolean(reader.readLine());
            pileColor = reader.readLine();

            String line;
            while ((line = reader.readLine()) != null) {
                if (line.equals("DISCARD_PILE")) break;

                String[] playerInfo = line.split(",");
                String playerName = playerInfo[0];
                boolean isHuman = Boolean.parseBoolean(playerInfo[1]);
                Player player = isHuman ? new HumanPlayer(playerName, true) : new ComputerBot(playerName, false);

                while ((line = reader.readLine()) != null && !line.equals("END_PLAYER_CARDS")) {
                    String[] cardInfo = line.split(",");
                    Card card = identifyCardByType(cardInfo);
                    player.addCardToHand(card);
                }

                players.add(player);
            }

            while ((line = reader.readLine()) != null && !line.equals("END_DISCARD_PILE")) {
                String[] cardInfo = line.split(",");
                Card card = identifyCardByType(cardInfo);
                discardPile.add(card);
                discardPileTopCard = card;
            }

            if ((line = reader.readLine()).equals("DECK")) {
                while ((line = reader.readLine()) != null && !line.equals("END_DECK")) {
                    String[] cardInfo = line.split(",");
                    Card card = identifyCardByType(cardInfo);
                    deckCards.add(card);
                }
            }
        }

        deck = new Deck(deckCards);
        return new GameSession(sessionName, players, deck, discardPile, currentPlayerIndex, isClockwise, pileColor, discardPileTopCard);
    }

    /**
     * Creates a Card instance based on the provided parameters.
     *
     * @param cardInfo the array containing card information
     * @return the created Card instance
     */
    private static Card identifyCardByType(String[] cardInfo) {
        String color = cardInfo[0];
        String value = cardInfo[1];
        String type = cardInfo[2];

        switch (type) {
            case "NumberCard":
                return new NumberCard(color, value);
            case "ActionCard":
                ActionCard.ActionType actionType = ActionCard.ActionType.valueOf(cardInfo[3].toUpperCase());
                return new ActionCard(color, actionType);
            case "WildCard":
                WildCard.WildType wildType = getWildType(cardInfo[3]);
                return new WildCard(wildType);
            default:
                throw new IllegalArgumentException("Unknown card type: " + type);
        }
    }

    /**
     * Gets the WildCard.WildType enum constant, defaulting to DRAW_FOUR if the value is not recognized.
     *
     * @param value the string representation of the WildType
     * @return the corresponding WildType enum constant
     */
    private static WildCard.WildType getWildType(String value) {
        try {
            return WildCard.WildType.valueOf(value.toUpperCase().replace(" ", "_"));
        } catch (IllegalArgumentException e) {
            return WildCard.WildType.DRAW_FOUR; // or any default value
        }
    }

    // Get list of saved games (this method assumes the use of a specific file extension, e.g., .txt)
    public static String[] getSavedGames() {
        File folder = new File(SAVE_FILE_PATH);
        return folder.list((dir, name) -> name.endsWith(".txt"));
    }
}
