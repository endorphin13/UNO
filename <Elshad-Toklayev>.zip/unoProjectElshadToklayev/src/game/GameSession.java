package game;

import java.util.ArrayList;
import java.util.List;

import cards.*;
import players.*;

/**
 * Represents a session of the UNO game, handling all game logic and state
 * management.
 */
public class GameSession {
	private String sessionName;
	private List<Player> players;
	private Deck deck;
	private List<Card> discardPile;
	private int currentPlayerIndex;
	private boolean isClockwise; // true clockwise, false for counterclockwise
	private boolean isGameActive;
	private Card discardPileTopCard;
	private boolean nextPlayerSkipTurn;
	private String pileColor;
	private Player winner;

	/**
	 * Constructs a new GameSession.
	 *
	 * @param players the list of players participating in the game
	 */
	public GameSession(String name, List<Player> players) {
		this.players = players;
		this.deck = new Deck();
		this.deck.shuffle();
		this.discardPile = new ArrayList<>();
		this.currentPlayerIndex = 0;
		this.discardPileTopCard = null;
		this.isClockwise = true;
		this.isGameActive = true;
		this.nextPlayerSkipTurn = false;
		this.winner = null;
		this.sessionName = name;
		initializePlayers();
		
	}
	
	/**
	 * Overloaded Constructor for loading games.
	 *
	 * @param players the list of players participating in the game
	 */
    public GameSession(String name, List<Player> players, Deck deck, List<Card> discardPile, int currentPlayerIndex, boolean isClockwise, String pileColor, Card discardPileTopCard) {
        this.sessionName = name;
        this.players = players;
        this.deck = deck;
        this.discardPile = discardPile;
        this.currentPlayerIndex = currentPlayerIndex;
        this.isClockwise = isClockwise;
        this.pileColor = pileColor;
        this.discardPileTopCard = discardPileTopCard;
        this.isGameActive = true; 
        this.nextPlayerSkipTurn = false; 
        this.winner = null; 
    }

	public Player getWinner() {
		return winner;
	}

	public void setWinner(Player winner) {
		this.winner = winner;
	}

	public boolean isClockwise() {
		return isClockwise;
	}

	public void setClockwise(boolean isClockwise) {
		this.isClockwise = isClockwise;
	}

	public String getPileColor() {
		return pileColor;
	}

	public void setPileColor(String pileColor) {
		this.pileColor = pileColor;
	}

	public Card getDiscardPileTopCard() {
		return discardPileTopCard;
	}

	public void setDiscardPileTopCard(Card discardPileTopCard) {
		this.discardPileTopCard = discardPileTopCard;
	}

	public List<Player> getPlayers() {
		return players;
	}

	public void setPlayers(List<Player> players) {
		this.players = players;
	}

	public Deck getDeck() {
		return deck;
	}

	public void setDeck(Deck deck) {
		this.deck = deck;
	}

	public List<Card> getDiscardPile() {
		return discardPile;
	}

	public void setDiscardPile(List<Card> discardPile) {
		this.discardPile = discardPile;
	}

	public int getCurrentPlayerIndex() {
		return currentPlayerIndex;
	}

	public void setCurrentPlayerIndex(int currentPlayerIndex) {
		this.currentPlayerIndex = currentPlayerIndex;
	}

	public boolean isGameActive() {
		return isGameActive;
	}

	public void setGameActive(boolean isGameActive) {
		this.isGameActive = isGameActive;
	}

	public boolean isNextPlayerSkipTurn() {
		return nextPlayerSkipTurn;
	}

	public void setNextPlayerSkipTurn(boolean nextPlayerSkipTurn) {
		this.nextPlayerSkipTurn = nextPlayerSkipTurn;
	}

	/**
	 * Reverses the direction of play.
	 */
	public void reverseGameDirection() {
		setClockwise(!isClockwise());
	}

	/**
	 * Initializes the players by drawing 7 cards for each player and ensuring the top card of the discard pile is a NumberCard.
	 */
	public void initializePlayers() {
		for (Player player : getPlayers()) {
			for (int i = 0; i < 7; i++) {
				Card drawnCard = getDeck().draw();
				player.addCardToHand(drawnCard);
			}
		}

		Card topCard = getDeck().draw();
		while (!(topCard instanceof NumberCard)) {
			getDeck().shuffleBackInCard(topCard);
			topCard = getDeck().draw();
		}

		setDiscardPileTopCard(topCard);
		setPileColor(getDiscardPileTopCard().getColor());
	}

	/**
	 * Plays a turn for the current player, handling card play or draw and checking for a winner.
	 */
	public void playTurn() {
		Player currentPlayer = players.get(currentPlayerIndex);

		if (nextPlayerSkipTurn) {
			System.out.println(currentPlayer.getName() + "'s turn is skipped.");
			nextPlayerSkipTurn = false;
			nextPlayer();
			return;
		}

		Card cardToPlay = getPlayableCardForCurrentPlayer();
		if (cardToPlay != null) {
			executeCardPlay(cardToPlay, currentPlayer);
		} else {
			handlePlayerDrawsCard(currentPlayer);
		}

		determineWinner();
		if (!isGameActive) {
			System.out.println("Game Over.");
			return;
		}

		nextPlayer();
	}

	/**
	 * Executes the play of a card by a player, updating the game state accordingly.
	 *
	 * @param card the card being played
	 * @param player the player playing the card
	 */
	public void executeCardPlay(Card card, Player player) {
	    String cardDetails = "";

	    if (card instanceof ActionCard) {
	        ActionCard actionCard = (ActionCard) card;
	        cardDetails = actionCard.getColor() + " " + actionCard.getActionType();
	    } else if (card instanceof WildCard) {
	        WildCard wildCard = (WildCard) card;
	        cardDetails = "Wild " + wildCard.getWildType();
	    } else {
	        cardDetails = card.getColor() + " " + card.getValue();
	    }

	    System.out.println(player.getName() + " plays " + cardDetails);
	    discardPile.add(card);
	    player.getPlayerCards().remove(card);
	    setDiscardPileTopCard(card);

	    card.playCard(this);

	    if (card instanceof WildCard) {
	        WildCard wildCard = (WildCard) card;
	        if (wildCard.getWildType() == WildCard.WildType.DRAW_FOUR) {
	            nextPlayerSkipTurn = true;
	        }
	    } else if (card instanceof ActionCard) {
	        ActionCard actionCard = (ActionCard) card;
	        if (actionCard.getActionType() == ActionCard.ActionType.DRAW_TWO) {
	            nextPlayerSkipTurn = true;
	        }
	    }
	}


	/**
	 * Handles a player drawing a card when they have no playable cards.
	 *
	 * @param player the player drawing a card
	 */
	public void handlePlayerDrawsCard(Player player) {
		System.out.println(player.getName() + " has no playable card and draws a card.");
		for (Card card : player.getPlayerCards()) {
			System.out.println(card + "\n");
		}
		Card drawnCard = deck.draw();
		player.addCardToHand(drawnCard);
		if (isValidPlay(drawnCard)) {
			System.out.println(player.getName() + " can play the drawn card.");
			executeCardPlay(drawnCard, player);
		}
	}

	/**
	 * Checks if a given card can be legally played based on the current top card of the discard pile and the game rules.
	 *
	 * @param card the card to check
	 * @return true if the card can be legally played, false otherwise
	 */
	public boolean isValidPlay(Card card) {
	    Card topCard = getDiscardPileTopCard();

	    if (card.getColor().equals(getPileColor()) || 
	        (!(card instanceof ActionCard) && card.getValue().equals(topCard.getValue()))) {
	        return true;
	    }

	    if (card instanceof WildCard) {
	        return true;
	    }

	    if (card instanceof ActionCard) {
	        ActionCard actionCard = (ActionCard) card;
	        if (topCard instanceof ActionCard) {
	            ActionCard topActionCard = (ActionCard) topCard;
	            if (actionCard.getActionType() == topActionCard.getActionType() ||
	                actionCard.getColor().equals(topActionCard.getColor())) {
	                return true;
	            }
	        } else if (card.getColor().equals(topCard.getColor())) {
	            return true;
	        }
	    }

	    return false;
	}




	/**
	 * Advances to the next player's turn, adjusting the current player index based on the direction of play.
	 */
	public void nextPlayer() {
	    if (nextPlayerSkipTurn) {
	        nextPlayerSkipTurn = false;
	        if (isClockwise) {
	            this.currentPlayerIndex = (currentPlayerIndex + 1) % this.players.size();
	        } else {
	            this.currentPlayerIndex = (currentPlayerIndex - 1 + this.players.size()) % players.size();
	        }
	    }
	    
	    if (isClockwise) {
	        this.currentPlayerIndex = (currentPlayerIndex + 1) % this.players.size();
	    } else {
	        this.currentPlayerIndex = (currentPlayerIndex - 1 + this.players.size()) % players.size();
	    }
	}


	/**
	 * Handles the color change effect for wild cards, considering whether the player is human or a bot.
	 *
	 * @param player the player changing the color
	 */
	public void handleColorChange(Player player) {
		if (player instanceof ComputerBot) {
			((ComputerBot) player).chooseColorRandomly(this);
		}
	}

	/**
	 * Checks all players to determine if a winner has emerged (i.e., a player with no cards left).
	 */
	public void determineWinner() {
		for (Player player : players) {
			if (player.getPlayerCards().isEmpty()) {
				isGameActive = false;
				setWinner(player);
				break;
			}
		}
	}

	/**
	 * Retrieves the first playable card from the current player's hand.
	 *
	 * @return the first card that can be legally played from the current player's hand, or null if no playable card is found.
	 */
	public Card getPlayableCardForCurrentPlayer() {
		Player currentPlayer = players.get(currentPlayerIndex);
		for (Card card : currentPlayer.getPlayerCards()) {
			if (isValidPlay(card)) {
				return card;
			}
		}
		return null;
	}

	/**
	 * Replenishes the deck from the discard pile, excluding the top card.
	 */
	public void replenishDeckFromDiscardPile() {
		if (discardPile.size() > 1) {
			Card topCard = discardPile.remove(discardPile.size() - 1);
			getDeck().getCards().addAll(discardPile);
			discardPile.clear();
			discardPile.add(topCard);
			deck.shuffle();
		}
	}

	/**
	 * Calculates and assigns the score to the winner based on the remaining cards held by other players.
	 */
	public void countWinnerScore() {
		int score = 0;
		for (Player player : players) {
			if (player != winner) {
				for (Card card : player.getPlayerCards()) {
					score += card.getScore();
				}
			}
		}
		if (winner != null) {
			winner.setScore(score);
		}
	}

	public String getSessionName() {
		return sessionName;
	}

	public void setSessionName(String sessionName) {
		this.sessionName = sessionName;
	}
}
