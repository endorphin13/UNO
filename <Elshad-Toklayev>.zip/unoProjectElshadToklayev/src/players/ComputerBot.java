package players;

import java.util.LinkedList;
import java.util.List;
import java.util.Random;

import cards.Card;
import game.GameSession;

/**
 * The ComputerBot class represents a computer-controlled player in the UNO game.
 */
public class ComputerBot extends Player {
	
	private List<Card> playerCards;

	/**
	 * Constructs a new ComputerBot with the specified name and human status.
	 *
	 * @param name the name of the computer bot
	 * @param isHuman a boolean indicating if the player is human (always false for ComputerBot)
	 */
	public ComputerBot(String name, boolean isHuman) {
		super(name, false);
		this.playerCards = new LinkedList<Card>();
	}

	/**
	 * Gets the list of cards held by the computer bot.
	 *
	 * @return the list of player cards
	 */
	public List<Card> getPlayerCards() {
		return playerCards;
	}

	/**
	 * Sets the list of cards held by the computer bot.
	 *
	 * @param playerCards the new list of player cards
	 */
	public void setPlayerCards(List<Card> playerCards) {
		this.playerCards = playerCards;
	}

	/**
	 * Chooses a color randomly for the game when a WildCard is played.
	 *
	 * @param game the current game session
	 */
	public void chooseColorRandomly(GameSession game) {
		String[] colors = {"Red", "Yellow", "Blue", "Green"};
		String selectedColor = colors[new Random().nextInt(colors.length)];
		game.setPileColor(selectedColor);
	}
}
