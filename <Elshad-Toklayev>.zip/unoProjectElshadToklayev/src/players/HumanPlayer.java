package players;

import java.util.ArrayList;
import java.util.List;

import cards.Card;

/**
 * The HumanPlayer class represents a human-controlled player in the UNO game.
 */
public class HumanPlayer extends Player {
	
	private List<Card> playerCards;

	/**
	 * Constructs a new HumanPlayer with the specified name and human status.
	 *
	 * @param name the name of the human player
	 * @param isHuman a boolean indicating if the player is human (always true for HumanPlayer)
	 */
	public HumanPlayer(String name, boolean isHuman) {
		super(name, true);
		this.playerCards = new ArrayList<Card>();
	}

	/**
	 * Gets the list of cards held by the human player.
	 *
	 * @return the list of player cards
	 */
	public List<Card> getPlayerCards() {
		return playerCards;
	}

	/**
	 * Sets the list of cards held by the human player.
	 *
	 * @param playerCards the new list of player cards
	 */
	public void setPlayerCards(List<Card> playerCards) {
		this.playerCards = playerCards;
	}
}
