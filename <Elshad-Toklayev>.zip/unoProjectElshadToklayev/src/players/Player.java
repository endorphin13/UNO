package players;

import java.util.ArrayList;
import java.util.List;

import cards.Card;
import cards.Deck;
import game.GameSession;

/**
 * The Player class represents a player in the UNO game, either human or computer.
 */
public class Player {
	private String id;
	private String name;
	private List<Card> playerCards;
	private boolean isHuman;
	private int score;

	/**
	 * Constructs a new Player with the specified name and human status.
	 *
	 * @param name the name of the player
	 * @param isHuman a boolean indicating if the player is human
	 */
	public Player(String name, boolean isHuman) {
		this.name = name;
		this.isHuman = isHuman;
		this.playerCards = new ArrayList<Card>();
		this.score = 0;
	}

	public int getScore() {
		return score;
	}

	public void setScore(int score) {
		this.score = score;
	}

	/**
	 * Adds a card to the player's hand.
	 *
	 * @param card the card to be added
	 */
	public void addCardToHand(Card card) {
		getPlayerCards().add(card);
	}

	/**
	 * Removes a card from the player's hand.
	 *
	 * @param card the card to be removed
	 */
	public void playCard(Card card) {
		getPlayerCards().remove(card);
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public List<Card> getPlayerCards() {
		return playerCards;
	}

	public void setPlayerCards(List<Card> playerCards) {
		this.playerCards = playerCards;
	}

	public boolean isHuman() {
		return isHuman;
	}

	public void setHuman(boolean isHuman) {
		this.isHuman = isHuman;
	}

	/**
	 * Removes a card from the player's hand at the specified index.
	 *
	 * @param index the index of the card to be removed
	 */
	public void removeCard(int index) {
		playerCards.remove(index);
	}

	/**
	 * Draws the specified number of cards from the deck and adds them to the player's hand.
	 *
	 * @param a the number of cards to draw
	 * @param deck the deck to draw the cards from
	 */
	public void drawCards(int a, Deck deck) {
		for (int i = 0; i < a; i++) {
			this.getPlayerCards().add(deck.draw());
		}
	}

	/**
	 * Gets a playable card from the player's hand based on the current game session.
	 *
	 * @param gameSession the current game session
	 * @return a playable card if found, otherwise null
	 */
	public Card getPlayableCard(GameSession gameSession) {
		for (Card card : this.playerCards) {
			if (gameSession.isValidPlay(card)) {
				return card;
			}
		}
		return null;
	}

	/**
	 * Returns a string representation of the player and their cards.
	 *
	 * @return a string representation of the player and their cards
	 */
	@Override
	public String toString() {
		StringBuilder sb = new StringBuilder();
		sb.append(name).append(" has the following cards:\n");
		for (Card card : getPlayerCards()) {
			sb.append(card.toString()).append("\n");
		}
		return sb.toString();
	}
}
